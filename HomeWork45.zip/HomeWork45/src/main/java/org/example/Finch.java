package org.example;

public abstract class Finch implements Bird{
    @Override
    public void sitDown() {
        System.out.println("Зяблик, садись");
    }
}
