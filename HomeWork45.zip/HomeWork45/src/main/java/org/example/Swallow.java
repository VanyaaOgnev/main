package org.example;

public abstract class Swallow implements Bird {

    @Override
    public void takeOff() {
        System.out.println("Ласточка, взлетай");
    }
}
