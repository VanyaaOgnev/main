package org.example;

public interface Bird   {
    void takeOff();
     void sitDown();

}
