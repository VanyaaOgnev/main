package org.example;

public class Main   {
    public static void main(String[] args) {
        Swallow swallow = new Swallow() {
            @Override
            public void sitDown() {
            }
        };
        swallow.takeOff();
        Finch finch = new Finch() {
            @Override
            public void takeOff() {
            }
        };
        finch.sitDown();

    }
}
